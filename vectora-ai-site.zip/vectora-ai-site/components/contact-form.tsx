"use client";
import { FormEvent, useState } from "react";
import { ArrowUpRight, CheckCircle2, LoaderCircle } from "lucide-react";
export function ContactForm() {
  const [status, setStatus] = useState<"idle"|"loading"|"success"|"error">("idle");
  const [message, setMessage] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setStatus("loading"); setMessage("");
    const form = e.currentTarget; const data = Object.fromEntries(new FormData(form).entries());
    try { const res = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) }); const result = await res.json(); if (!res.ok) throw new Error(result.error || "Unable to send your message."); setStatus("success"); setMessage("Thanks — your enquiry has been sent. We’ll get back to you soon."); form.reset(); }
    catch (err) { setStatus("error"); setMessage(err instanceof Error ? err.message : "Something went wrong. Please email us directly."); }
  }
  return <form className="contact-form" onSubmit={submit}><div className="form-row"><label>Your name<input name="name" placeholder="Name" required minLength={2} maxLength={80}/></label><label>Work email<input name="email" type="email" placeholder="you@company.com" required maxLength={150}/></label></div><label>What do you need help with?<select name="service" defaultValue=""><option value="" disabled>Select a service</option><option>AI Agents</option><option>Workflow Automation</option><option>Lead Generation & CRM</option><option>Website or Web App</option><option>Custom AI Solution</option><option>Not sure yet</option></select></label><label>Tell us a little about your project<textarea name="details" rows={5} placeholder="What are you trying to improve or automate?" required minLength={10} maxLength={3000}/></label><input className="hp-field" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true"/><button className="button button-primary form-submit" type="submit" disabled={status === "loading"}>{status === "loading" ? <><LoaderCircle className="spin" size={17}/> Sending…</> : <>Send enquiry <ArrowUpRight size={17}/></>}</button>{message && <p className={`form-message ${status}`} role="status">{status === "success" && <CheckCircle2 size={17}/>} {message}</p>}<p className="form-note">Your details are only used to respond to this enquiry.</p></form>;
}
