"use client";
import Link from "next/link";
import { useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { whatsappUrl } from "@/lib/site";
const links = [{ href: "/services", label: "Services" }, { href: "/work", label: "Our work" }, { href: "/about", label: "About" }];
export function Header() {
  const [open, setOpen] = useState(false);
  return <header className="site-header"><div className="nav-wrap"><Link href="/" className="brand" aria-label="VECTORA AI home"><span className="brand-mark">V<span>+</span></span><span>VECTORA<span className="brand-ai">AI</span></span></Link><nav className="desktop-nav" aria-label="Main navigation">{links.map(l => <Link key={l.href} href={l.href}>{l.label}</Link>)}</nav><div className="nav-actions"><Link className="nav-cta" href="/contact">Let’s talk <ArrowUpRight size={15}/></Link><button className="menu-toggle" aria-label={open ? "Close menu" : "Open menu"} onClick={() => setOpen(!open)}>{open ? <X/> : <Menu/>}</button></div></div>{open && <nav className="mobile-nav">{links.map(l => <Link key={l.href} href={l.href} onClick={() => setOpen(false)}>{l.label}</Link>)}<Link href="/contact" onClick={() => setOpen(false)}>Contact <ArrowUpRight size={15}/></Link></nav>}</header>;
}
