import type { Metadata } from "next";
import "./globals.css";
import { Header } from "@/components/header";
import { Footer } from "@/components/footer";
import { siteConfig } from "@/lib/site";
export const metadata: Metadata = { metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://vectoraai.tech"), title: { default: "VECTORA AI — Building smarter businesses", template: "%s | VECTORA AI" }, description: siteConfig.description, openGraph: { title: "VECTORA AI", description: siteConfig.description, type: "website" } };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="en"><body><Header/><main>{children}</main><Footer/></body></html>; }
